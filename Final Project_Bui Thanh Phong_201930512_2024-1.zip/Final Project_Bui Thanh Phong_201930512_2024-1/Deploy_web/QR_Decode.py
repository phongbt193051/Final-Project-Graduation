import cv2
from pyzbar.pyzbar import decode
import os

# Đường dẫn tới thư mục chứa các mã QR
input_dir = 'qr_codes'

# Duyệt qua tất cả các tệp trong thư mục
for filename in os.listdir(input_dir):
    if filename.endswith('.png'):  # Chỉ xử lý tệp ảnh PNG
        file_path = os.path.join(input_dir, filename)
        
        # Đọc ảnh mã QR từ file
        img = cv2.imread(file_path)
        
        # Giải mã mã QR
        decoded_objects = decode(img)
        
        # In kết quả giải mã cho từng mã QR
        for obj in decoded_objects:
            print(f'File: {filename} - Data: {obj.data.decode("utf-8")}')
