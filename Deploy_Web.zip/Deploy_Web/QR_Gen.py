import qrcode
import os
import sys

# Đặt mã hóa utf-8 cho đầu ra console
sys.stdout.reconfigure(encoding='utf-8')

# Tạo thư mục để lưu các mã QR
output_dir = 'qr_codes'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Tạo mã QR cho các giá trị từ 0 đến 100
for i in range(101):
    # Tạo QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    
    data = str(i)  # Giá trị số từ 0 đến 100
    qr.add_data(data)
    qr.make(fit=True)

    # Tạo hình ảnh QR code với màu nền trắng và mã QR màu đen
    img = qr.make_image(fill_color="black", back_color="white")

    # Lưu mã QR vào file trực tiếp mà không dùng OpenCV
    file_path = os.path.join(output_dir, f'qrcode_{i}.png')
    img.save(file_path)

# In thông báo hoàn thành với UTF-8
print(f"Tất cả mã QR đã được lưu trong thư mục '{output_dir}'")
