import cv2
from pyzbar.pyzbar import decode
import os

# Đường dẫn tới thư mục chứa các mã QR
input_dir = 'E:\\Final Project_Bui Thanh Phong_201930512_2024-1\\QR_1_to_20'  # Thay bằng đường dẫn thực tế tới thư mục của bạn

# Duyệt qua tất cả các tệp trong thư mục
for filename in os.listdir(input_dir):
    if filename.endswith('.png') or filename.endswith('.jpg'):  # Chỉ xử lý tệp ảnh PNG hoặc JPG
        file_path = os.path.join(input_dir, filename)
        
        # Đọc ảnh mã QR từ file
        img = cv2.imread(file_path)
        
        # Giải mã mã QR
        decoded_objects = decode(img)
        
        # Kiểm tra nếu có mã QR được giải mã
        if decoded_objects:
            # In tên ảnh và giải mã của nó
            for obj in decoded_objects:
                qr_data = obj.data.decode('utf-8')
                print(f'{filename} --- Giải mã: {qr_data}')
        else:
            # Nếu không giải mã được mã QR, in thông báo
            print(f'{filename} --- Không tìm thấy mã QR')

