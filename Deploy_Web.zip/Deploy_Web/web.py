
import cv2
import time
import torch
import numpy as np
from flask import Flask, render_template, Response
from yolov5.models.experimental import attempt_load
from yolov5.utils.general import non_max_suppression, scale_boxes
from yolov5.utils.torch_utils import select_device
import threading
import pathlib

# Fix for compatibility between different path systems
temp = pathlib.PosixPath
pathlib.PosixPath = pathlib.WindowsPath

app = Flask(__name__)

def plot_one_box(x, img, color=None, label=None, line_thickness=None):
    tl = line_thickness or round(0.002 * max(img.shape[0:2])) + 1
    color = color or [np.random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)
        cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [0, 0, 0], thickness=tf, lineType=cv2.LINE_AA)

# Load YOLOv5 model
device = select_device('')
model = attempt_load('E:\\Final Project_Bui Thanh Phong_201930512_2024-1\\YOLOFMM\\runs\\train\\exp24\\weights\\best.pt', device=device)
model.eval()
if device.type != 'cpu':
    model.half()

stride = int(model.stride.max())
names = model.module.names if hasattr(model, 'module') else model.names

class VideoCamera:
    def __init__(self):
        self.video = cv2.VideoCapture(0)
        self.start_time = time.time()
        self.frame_count = 0
        self.frame = None
        self.lock = threading.Lock()
        self.running = True
        threading.Thread(target=self.update, daemon=True).start()

    def __del__(self):
        self.video.release()
        self.running = False

    def update(self):
        while self.running:
            success, frame = self.video.read()
            if success:
                with self.lock:
                    self.frame = frame

    def get_frame(self):
        with self.lock:
            frame = self.frame

        if frame is None:
            return None

        img = cv2.resize(frame, (160, 160))
        img = torch.from_numpy(img).to(device)
        img = img.permute(2, 0, 1).float().unsqueeze(0) / 255.0
        if device.type != 'cpu':
            img = img.half()

        with torch.no_grad():
            pred = model(img)[0]
            pred = non_max_suppression(pred, 0.4, 0.5)

        for i, det in enumerate(pred):
            if len(det):
                det[:, :4] = scale_boxes(img.shape[2:], det[:, :4], frame.shape).round()
                for *xyxy, conf, cls in reversed(det):
                    if names[int(cls)] in ['smoke', 'fire']:
                        label = f'{names[int(cls)]} {conf:.2f}'
                        plot_one_box(xyxy, frame, label=label, color=(0, 0, 255))

        self.frame_count += 1
        elapsed_time = time.time() - self.start_time
        fps = self.frame_count / elapsed_time

        cv2.putText(frame, f"FPS: {round(fps, 0)}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

        ret, buffer = cv2.imencode('.jpg', frame)

        return buffer.tobytes()

def gen(camera):
    while True:
        frame = camera.get_frame()
        if frame is not None:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(gen(VideoCamera()), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True)