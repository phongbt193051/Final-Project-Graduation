import cv2
import torch
import time
import numpy as np
from flask import Flask, render_template, Response

# Define plot_one_box function
def plot_one_box(x, img, color=None, label=None, line_thickness=None):
    """
    Plots one bounding box on image img.
    Arguments:
        x: a list containing the bounding box coordinates [x1, y1, x2, y2]
        img: the image to draw on
        color: color of the bounding box
        label: label to display with the bounding box
        line_thickness: thickness of the bounding box lines
    """
    tl = line_thickness or round(0.002 * max(img.shape[0:2])) + 1  # line thickness
    color = color or [np.random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3, [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)

class VideoCamera:
    def __init__(self):
        self.video = cv2.VideoCapture(0)  # Change the argument if you are using a different camera index
        self.model = torch.hub.load('ultralytics/yolov5', 'custom', path='E:\\Final Project_Bui Thanh Phong_201930512_2024-1\\YOLOFMM\\runs\\train\\exp24\\weights\\best.pt')  # Load your trained model
        self.model.eval()
        self.start_time = time.time()
        self.frame_count = 0

    def __del__(self):
        self.video.release()

    def get_frame(self):
        success, frame = self.video.read()

        if not success:
            return None

        # Perform inference
        results = self.model(frame)

        # Extract detections
        detections = results.xyxy[0].cpu().numpy()

        # Draw bounding boxes and labels on the frame
        for *xyxy, conf, cls in detections:
            label = f'{self.model.names[int(cls)]} {conf:.2f}'
            plot_one_box(xyxy, frame, label=label, color=(0, 255, 0), line_thickness=2)

        # Calculate FPS
        self.frame_count += 1
        elapsed_time = time.time() - self.start_time
        fps = self.frame_count / elapsed_time

        # Overlay FPS on the frame
        cv2.putText(frame, f"FPS: {round(fps, 0)}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

        # Encode the frame in JPEG format
        ret, buffer = cv2.imencode('.jpg', frame)

        return buffer.tobytes()
